# Parameter Golf — Autoresearch Setup

Autonomous AI-driven experimentation for the OpenAI Parameter Golf challenge,
inspired by [Karpathy's autoresearch](https://github.com/karpathy/autoresearch).

An AI agent (Claude Code, Codex, etc.) edits `train_gpt.py`, runs experiments,
keeps improvements, discards failures, and iterates — all while you sleep.

## Quick Start

### 1. Prepare the server

```bash
# On your H100 server, clone parameter golf
cd /workspace
git clone https://github.com/massaindustries/parameter-golf-massa.git
cd parameter-golf-massa

# Install dependencies
pip install -r requirements.txt

# Download dataset (~8GB)
python3 data/cached_challenge_fineweb.py --variant sp1024
```

### 2. Copy autoresearch files into the repo

```bash
# Copy these files into your parameter-golf-massa repo root:
cp /path/to/program.md .
cp /path/to/constraints.md .
cp /path/to/run_experiment.sh .
chmod +x run_experiment.sh
```

### 3. Verify baseline

```bash
# Quick smoke test (500 steps, ~3 min)
ITERATIONS=500 bash run_experiment.sh

# Full experiment run (2000 steps, ~12 min)
bash run_experiment.sh
```

### 4. Launch the agent

Point your coding agent at `program.md` and let it go:

```bash
# With Claude Code:
claude-code "Read program.md and start the autoresearch experiment loop"

# With Codex:
# Open the repo, point it at program.md, let it run
```

The agent will:
1. Read `program.md` for instructions
2. Read `train_gpt.py` for full context
3. Read `constraints.md` for hard rules
4. Establish a baseline
5. Start modifying and testing changes
6. Log everything to `results.tsv`
7. Keep only improvements
8. Run indefinitely until you stop it

### 5. Check results in the morning

```bash
# See all experiments
cat results.tsv

# See only improvements
grep "keep" results.tsv

# See the current best val_bpb
grep "keep" results.tsv | sort -t$'\t' -k2 -n | head -1

# See git log of kept changes
git log --oneline autoresearch/<tag>
```

## File Structure

```
parameter-golf-massa/
├── train_gpt.py          # THE ONLY FILE THE AGENT EDITS
├── program.md            # Agent instructions (read-only)
├── constraints.md        # Challenge rules (read-only)
├── run_experiment.sh     # Experiment runner (read-only)
├── results.tsv           # Experiment log (written by agent, not committed)
├── data/
│   ├── datasets/fineweb10B_sp1024/   # Training + validation data
│   └── tokenizers/                    # SentencePiece tokenizer
├── logs/                              # Training logs per run
└── records/                           # Official submission records
```

## How It Works

Each experiment cycle (~12 minutes):

1. Agent picks ONE change to try (hyperparameter or architecture)
2. Edits `train_gpt.py`
3. Commits the change
4. Runs `bash run_experiment.sh > run.log 2>&1`
5. Extracts `val_bpb` and `model_size` from the log
6. If improved AND under 16MB → keeps the commit
7. If worse or over 16MB → reverts with `git reset --hard HEAD~1`
8. Logs the result to `results.tsv`
9. Repeats

Expected throughput: ~5 experiments/hour on 1xH100, ~40 experiments overnight.

## Iteration Budget

The default 2000-step budget gives fast feedback (~12 min per run on 1xH100).
This is NOT the final submission quality — it's for relative comparisons.

Once you've found a good configuration, do a full validation run:
```bash
ITERATIONS=20000 bash run_experiment.sh
```

## Safety Notes

- The agent only touches `train_gpt.py` — no other files
- All changes are git-committed, so you have full history
- Failed experiments are reverted, so the branch always represents the best known config
- `results.tsv` tracks everything including failures and crashes
- Model size is checked after every run to catch 16MB violations early
