# Parameter Golf Autoresearch

Autonomous experimentation loop for OpenAI's Parameter Golf challenge.
Goal: train the best language model that fits in 16MB, measured by bits-per-byte (val_bpb).

## Setup

To set up a new experiment, work with the user to:

1. **Agree on a run tag**: propose a tag based on today's date (e.g. `mar24`). The branch `autoresearch/<tag>` must not already exist.
2. **Create the branch**: `git checkout -b autoresearch/<tag>` from current main.
3. **Read the in-scope files**: Read these files for full context:
   - This `program.md` — experiment rules and constraints.
   - `train_gpt.py` — the file you modify. Model architecture, optimizer, training loop, evaluation, quantization.
4. **Verify data exists**: Check that `./data/datasets/fineweb10B_sp1024/` contains data shards and `./data/tokenizers/` contains the tokenizer. If not, tell the human to run `bash prepare.sh`.
5. **Initialize results.tsv**: Create `results.tsv` with just the header row. The baseline will be recorded after the first run.
6. **Confirm and go**: Confirm setup looks good.

Once you get confirmation, kick off the experimentation.

## Challenge Context

This is OpenAI's Parameter Golf challenge. The rules are:

- **Artifact limit**: code bytes + compressed model bytes must be under **16,000,000 bytes** (decimal, not MiB).
- **Training budget**: must complete in under 10 minutes on 8×H100 (for final submission). For our experiments, we use a **5-minute cap on 1×H100**.
- **Evaluation budget**: evaluation must also complete in under 10 minutes on 8×H100 (final submission).
- **Metric**: `val_bpb` (bits per byte) on the fixed FineWeb validation set. Lower is better.
- **No cheating**: no training on the validation set, no network calls during evaluation.
- **The score that counts**: `final_int8_zlib_roundtrip val_bpb` — this is the post-quantization score printed at the end of the run.

Current SOTA leaderboard is ~1.12 bpb. Our baseline on 1×H100 with reduced time will be higher.

## Experimentation

Each experiment runs on a single GPU. Training runs for a fixed **5 minutes** wall clock.

Launch command:
```bash
RUN_ID=autoresearch \
MAX_WALLCLOCK_SECONDS=300 \
TRAIN_LOG_EVERY=500 \
VAL_LOSS_EVERY=0 \
torchrun --standalone --nproc_per_node=1 train_gpt.py > run.log 2>&1
```

**What you CAN modify** (all inside `train_gpt.py`):

- Model architecture: number of layers, model dimension, number of heads, number of KV heads, MLP multiplier
- Optimizer hyperparameters: learning rates (embed_lr, matrix_lr, scalar_lr, tied_embed_lr), momentum, warmup/warmdown steps, beta1/beta2
- Training batch size and sequence length
- Activation functions (relu², gelu, swiglu, etc.)
- Attention variants (GQA ratios, window patterns, sliding window)
- Normalization strategies
- Embedding strategy (tied vs untied, init std)
- Skip connection patterns
- Adding bias terms to linear layers
- Logit softcap value
- RoPE base frequency
- QK gain init
- Any architectural innovation that stays within a single file

**What you CANNOT modify**:

- The data files or data paths (they are fixed)
- The tokenizer or vocabulary size (1024 BPE, fixed)
- The evaluation formula (eval_val function logic for bpb calculation)
- The quantization format (int8 + zlib) — you can tune percentile clipping but not the scheme
- The output format (the script must still print `final_int8_zlib_roundtrip val_bpb:X.XXXX`)
- Do NOT add external package dependencies
- Do NOT add network calls
- Do NOT modify data loading to touch validation files during training

**Hard constraints to check after every run**:

1. `val_bpb` must be a valid number (not nan, not inf)
2. `Total submission size int8+zlib` must be **under 16,000,000 bytes**
3. The run must complete without crashing

If the submission size exceeds 16MB, the experiment is **invalid** regardless of val_bpb. Log it as `discard` with a note about size violation.

## Output format

After the run finishes, the script prints several lines. The key metrics are:

```
final_int8_zlib_roundtrip val_loss:X.XXXX val_bpb:X.XXXX eval_time:XXXXms
final_int8_zlib_roundtrip_exact val_loss:X.XXXXXXXX val_bpb:X.XXXXXXXX
Total submission size int8+zlib: XXXXXXX bytes
```

Extract them with:
```bash
grep "final_int8_zlib_roundtrip_exact\|Total submission size int8" run.log
```

The primary metric is the `val_bpb` from `final_int8_zlib_roundtrip_exact`.
The size constraint is from `Total submission size int8+zlib`.

If neither line appears, the run crashed. Run `tail -n 50 run.log` to debug.

## Logging results

When an experiment is done, log it to `results.tsv` (tab-separated, NOT comma-separated).

The TSV has a header row and 7 columns:

```
commit	val_bpb	size_bytes	size_ok	status	param_changes	description
```

1. git commit hash (short, 7 chars)
2. val_bpb achieved (from final_int8_zlib_roundtrip_exact) — use 0.000000 for crashes
3. total submission size in bytes (from Total submission size int8+zlib) — use 0 for crashes
4. size_ok: `yes` if under 16000000, `no` if over — use `n/a` for crashes
5. status: `keep`, `discard`, or `crash`
6. param_changes: concise list of env vars or code changes (e.g. "NUM_LAYERS=11 MODEL_DIM=448")
7. short text description of what this experiment tried and the reasoning

Example:

```
commit	val_bpb	size_bytes	size_ok	status	param_changes	description
a1b2c3d	1.2244	15863489	yes	keep	baseline	baseline run with default hyperparameters
b2c3d4e	1.2180	15901234	yes	keep	NUM_LAYERS=11 MODEL_DIM=448	more layers with smaller dim to stay under 16MB
c3d4e5f	1.2350	14500000	yes	discard	MLP_MULT=3	triple MLP width - too many params wasted on MLP
d4e5f6g	1.1900	17200000	no	discard	NUM_LAYERS=13 MODEL_DIM=512	better bpb but over 16MB size limit
e5f6g7h	0.0000	0	n/a	crash	NUM_HEADS=16	OOM error with 16 attention heads
```

## The experiment loop

LOOP FOREVER:

1. Look at the git state and results.tsv to understand what has been tried and what worked.
2. **Think about what to try next.** Consider:
   - What improved so far? Try variations of winning ideas.
   - What hasn't been explored yet?
   - Is there a size budget to spare? (if current model is 14MB, you have 2MB to add capacity)
   - Is there a size problem? (if over 16MB, reduce capacity)
3. Edit `train_gpt.py` with your experimental change. Keep changes **minimal and isolated** — one idea per experiment so you know what caused the improvement.
4. `git add train_gpt.py && git commit -m "description of change"`
5. Run the experiment:
   ```bash
   RUN_ID=autoresearch \
   MAX_WALLCLOCK_SECONDS=300 \
   TRAIN_LOG_EVERY=500 \
   VAL_LOSS_EVERY=0 \
   torchrun --standalone --nproc_per_node=1 train_gpt.py > run.log 2>&1
   ```
6. Extract results:
   ```bash
   grep "final_int8_zlib_roundtrip_exact\|Total submission size int8" run.log
   ```
7. If grep output is empty, the run crashed. Run `tail -n 50 run.log` to debug. If fixable (typo, import), fix and re-run. If fundamentally broken, log as crash and move on.
8. Check both val_bpb AND size. A run with great bpb but over 16MB is invalid.
9. Record results in results.tsv.
10. If val_bpb improved AND size is under 16MB, keep the commit (advance the branch).
11. If val_bpb is equal/worse OR size is over 16MB, `git reset --hard HEAD~1` to revert.

## Experiment Ideas (prioritized)

Start with the baseline, then explore in roughly this order:

### Tier 1: Architecture shape (high impact, easy to test)
- Number of layers: try 10, 11, 12, 13 (more layers = more capacity but more size)
- Model dimension: try 448, 480, 512, 576 (wider = more capacity per layer)
- NUM_KV_HEADS: try 2, 4, 8 (fewer KV heads = less size, might hurt quality)
- MLP_MULT: try 1, 2, 3, 4 (controls MLP width relative to model dim)
- Find the sweet spot: maximize capacity while staying under 16MB compressed

### Tier 2: Training dynamics (medium impact)
- Learning rates: try different matrix_lr (0.02, 0.04, 0.08), scalar_lr, embed_lr
- Warmdown iterations: try 800, 1200, 2000
- Muon momentum: try 0.90, 0.95, 0.99
- Muon backend steps: try 3, 5, 7
- Batch size: try 262144, 524288, 1048576 (TRAIN_BATCH_TOKENS)
- Sequence length: try 512, 1024, 2048 (TRAIN_SEQ_LEN)

### Tier 3: Architecture innovations (medium impact, more complex)
- Add bias to linear layers (small param cost, might help)
- Change activation: try LeakyReLU², GeLU, SwiGLU instead of relu²
- Gated attention (add a gate parameter to attention output)
- Value Residual connections
- Change logit_softcap: try 20, 30, 50
- RoPE base: try 5000, 10000, 50000
- EMA (exponential moving average) of weights for evaluation

### Tier 4: Compression optimization (small but free gains)
- Tune INT8_CLIP_PERCENTILE (currently 99.99984)
- Try per-channel vs per-tensor quantization thresholds

### Tier 5: Combine winners
- Once you have individual improvements, combine them

## Important principles

- **One change at a time.** If you change 3 things and the result improves, you don't know which one helped. Keep experiments atomic.
- **Size awareness.** Always check the submission size. The best bpb in the world is useless at 17MB.
- **Diminishing returns.** If you're getting 0.0001 improvements, try a more radical change direction.
- **Don't over-tune.** We're running on 1×H100 for 5 minutes. Some improvements won't transfer to the final 8×H100 10-minute run. Focus on robust architectural improvements, not micro-tuning.
- **Log everything.** The human will read results.tsv to understand what worked. Write clear descriptions.

## Timeout

Each experiment should take ~5 minutes of training + a few minutes of startup, compilation, evaluation. Total wall clock ~8 minutes. If a run exceeds 15 minutes total, kill it (`pkill -f torchrun`) and treat as failure.

## NEVER STOP

Once the experiment loop has begun, do NOT pause to ask the human if you should continue. The human might be asleep. You are autonomous. Run experiments indefinitely until manually interrupted. If you run out of ideas, re-read the code, try combining near-misses, try more radical changes. Aim for ~7 experiments per hour, ~50-80 overnight.
